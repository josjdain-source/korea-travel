// On-site AI guide. A QR at the location opens guide.html?id=<location>.
// It loads ONLY that location's knowledge and answers in a regional persona.
//
// ── Swapping in a real LLM ───────────────────────────────────────────────
// Today answers come from answerLocally() — a keyword/RAG engine over this
// one location's data, so the demo runs with NO API key. To use Claude/GPT/
// Gemini later, replace the body of generateAnswer() with an API call whose
// context is the `loc` object below. Nothing else needs to change.

// Region → guide character. This is what makes each QR feel like a local.
const PERSONAS = {
  Gyeongbuk: { name: "Seonbi Kim", role: "Joseon scholar guide", avatar: "🧎", greet: "Greetings, traveler. I have kept the stories of this place for generations." },
  Jeonnam:   { name: "Haerim",     role: "wetland & tea eco-guide", avatar: "🌿", greet: "Welcome! Breathe in — this land is alive. Ask me anything." },
  Gyeongnam: { name: "Pada",       role: "keeper of the southern sea", avatar: "🌊", greet: "Ahoy, friend. The sea brought you here — let me show you around." },
  Gangwon:   { name: "Misol",      role: "east-coast sea keeper", avatar: "🌅", greet: "Welcome to the east coast. The waves have many stories." },
  Jeonbuk:   { name: "Jun",        role: "old-port time guide", avatar: "🚢", greet: "Welcome to the old harbor — step back in time with me." },
};
const DEFAULT_PERSONA = { name: "Dari", role: "local guide", avatar: "🤖", greet: "Hi! Ask me anything about this place." };

let loc = null;
let persona = DEFAULT_PERSONA;

const log = document.getElementById("chat-log");
const header = document.getElementById("guide-header");
const suggestions = document.getElementById("suggestions");

init();

async function init() {
  const id = new URLSearchParams(location.search).get("id");
  let all = [];
  try {
    all = await (await fetch("data/locations.json")).json();
  } catch (e) {
    return fail("Could not load guide data.");
  }
  loc = all.find((l) => l.id === id);
  if (!loc) return fail("Unknown location. Scan a valid K-Drama Route QR code.");

  persona = PERSONAS[loc.region] || DEFAULT_PERSONA;
  if (typeof RR_MEM !== "undefined") RR_MEM.logEvent("guide_open", { place: loc.id });
  renderHeader();
  addMessage("ai", `${persona.greet}\n\nYou're at ${loc.nameEn} (${loc.nameKo}).`);
  renderSuggestions();
  document.getElementById("chat-form").addEventListener("submit", onSubmit);
}

function renderHeader() {
  header.innerHTML = `
    <a class="back" href="index.html">← K-Drama Route</a>
    <p class="persona-name">${persona.avatar} ${esc(persona.name)}</p>
    <p class="persona-role">${esc(persona.role)}</p>
    <p class="place">📍 ${esc(loc.nameEn)} · ${esc(loc.city)}, ${esc(loc.region)}</p>`;
}

// Intent-based answers. Each suggestion chip carries an explicit `intent`, so it
// works even when the page is auto-translated (Google Translate rewrites the
// visible button text). Typed questions match English OR Korean keywords.
// generateAnswer() stays the single swap point for a real (any-language) LLM.
const INTENTS = [
  { key: "why", kw: ["why famous", "why is it famous", "why popular", "blew up", "blow up", "known for", "so famous", "viral", "왜 유명", "왜 인기", "유명", "왜 떴"],
    label: "Why is it famous?", answer: (l) => l.whyFamous || shorten(l.description) },
  { key: "dramas", kw: ["drama", "movie", "film", "filmed", "shot here", "k-drama", "드라마", "영화", "촬영", "작품"],
    label: "Which dramas were filmed here?", answer: (l) => {
      const titles = (l.titles || []).map((x) => x.titleEn + (x.year ? ` (${x.year})` : "")).join(", ");
      return titles ? `This spot has appeared in: ${titles}. ${confNote(l)}` : `Several productions have used this location — I'm still confirming the exact titles.`;
    } },
  { key: "recreate", kw: ["recreate", "same shot", "copy the", "difficulty", "how hard", "do the same", "replicate", "재현", "따라", "난이도", "똑같"],
    label: "How do I recreate the shot?", answer: (l) => {
      const tip = l.photoTip ? l.photoTip + " " : "";
      const diff = l.difficulty ? `Recreation difficulty: ${l.difficulty}.` : "";
      return (tip + diff).trim() || `Match the on-screen framing and you've got the shot.`;
    } },
  { key: "photo", kw: ["photo", "picture", "angle", "instagram", "camera", "pose", "사진", "앵글", "구도"],
    label: "How do I take the same photo?", answer: (l) => l.photoTip || `Look for the framing you saw on screen — ${shorten(l.description)}` },
  { key: "scene", kw: ["scene", "famous scene", "iconic", "moment", "장면", "명장면"],
    label: "What's the most famous scene?", answer: (l) => `The most-photographed view here is the one you'll recognise from the screen — ${shorten(l.description)} Stand where the light falls and you'll spot it.` },
  { key: "bestTime", kw: ["best time", "when", "season", "sunrise", "sunset", "hour", "month", "crowd", "언제", "시간", "계절", "일출", "일몰", "붐"],
    label: "When's the best time to visit?", answer: (l) => l.bestTime || `Mild seasons (spring/autumn) and early mornings are usually best — softer light and fewer crowds.` },
  { key: "daytrip", kw: ["day trip", "itinerary", "course", "route", "one day", "plan", "schedule", "당일", "하루", "코스", "일정", "동선"],
    label: "Can I do this as a day trip?", answer: (l) => {
      const stops = (l.nearby || []).slice(0, 2);
      const plan = stops.length ? `Yes — a comfortable day: morning at ${l.nameEn}, then ${stops.join(" and ")} in the afternoon.` : `Yes, it works as a day trip.`;
      return `${plan} ${l.gettingThere || ""}`.trim();
    } },
  { key: "food", kw: ["eat", "food", "restaurant", "lunch", "dinner", "cafe", "coffee", "hungry", "맛집", "음식", "먹", "식당", "카페", "밥"],
    label: "Where can I eat nearby?", answer: (l) => {
      const food = (l.nearby || []).filter((n) => /restaurant|food|cafe|jjimdak|sausage|ice cream|cockle|tea|seafood|kkomak/i.test(n));
      const list = food.length ? food : (l.nearby || []).slice(0, 2);
      return list.length ? `Close by you can try: ${list.join("; ")}.` : `Ask a local stall nearby — the regional specialties are worth it.`;
    } },
  { key: "transport", kw: ["get back", "seoul", "train", "ktx", "bus", "how do i get", "transport", "leave", "교통", "가는 법", "가는법", "기차", "버스", "이동", "서울", "도착"],
    label: "How do I get back to Seoul?", answer: (l) => l.gettingThere || "Check the nearest KTX station or express bus terminal for return options." },
  { key: "safe", kw: ["safe", "alone", "solo", "dangerous", "by myself", "안전", "혼자", "위험"],
    label: "Is it safe to go alone?", answer: (l) => `This is a popular, well-visited spot and Korea is generally very safe for solo travelers. Use normal caution, keep an eye on the last bus/train times back from ${l.city}, and you'll be fine.` },
  { key: "creators", kw: ["who recommend", "recommended", "creator", "youtuber", "influencer", "vlog", "who went", "who filmed", "who visited", "누가", "크리에이터", "유튜버", "추천"],
    label: "Which creators went here?", answer: (l) => {
      if (l.visits && l.visits.length) return `Creators who've featured this spot: ` + l.visits.map((v) => v.creator).join(", ") + ".";
      return `I don't have any verified creator visits linked here yet. That's a curated, source-checked layer we add deliberately — I won't invent one.`;
    } },
  { key: "nearby", kw: ["around", "nearby", "what else", "anything else", "근처", "주변", "또 ", "볼거리"],
    label: "What else is around here?", answer: (l) => (l.nearby || []).length ? `Worth a stop nearby: ${l.nearby.join("; ")}.` : `Wander a little — this area rewards slow travelers.` },
  { key: "about", kw: ["what is", "what's this", "tell me", "where am i", "무엇", "이곳", "이 장소", "여기 뭐", "소개"],
    label: "What is this place?", answer: (l) => `${l.description} ${confNote(l)}` },
];
const CHIP_ORDER = ["about", "why", "dramas", "recreate", "bestTime", "daytrip", "food", "transport", "safe", "creators"];

function renderSuggestions() {
  suggestions.innerHTML = CHIP_ORDER.map((k) => INTENTS.find((i) => i.key === k))
    .filter(Boolean)
    .map((it) => `<button data-intent="${it.key}">${esc(it.label)}</button>`)
    .join("");
  suggestions.querySelectorAll("button").forEach((b) =>
    b.addEventListener("click", () => ask(b.textContent, b.dataset.intent))
  );
}

function onSubmit(e) {
  e.preventDefault();
  const field = document.getElementById("chat-field");
  const text = field.value.trim();
  if (!text) return;
  field.value = "";
  ask(text, null);
}

function ask(text, intent) {
  addMessage("user", text);
  const answer = generateAnswer(text, intent);
  setTimeout(() => addMessage("ai", answer), 250); // tiny delay → feels like a reply
}

// The single function to replace when wiring a real (any-language) LLM.
function generateAnswer(question, intent) {
  return answerLocally(question, intent, loc, persona);
}

function answerLocally(q, intent, l, p) {
  if (intent) {
    const it = INTENTS.find((x) => x.key === intent);
    if (it) return it.answer(l, p);
  }
  const t = String(q).toLowerCase();
  for (const it of INTENTS) {
    if (it.kw.some((w) => t.includes(w))) return it.answer(l, p);
  }
  return `${l.description}\n\nYou can ask me about the dramas filmed here, the famous scenes, nearby food, or how to travel on from ${l.city}.`;
}

function confNote(l) {
  return l.confidence && l.confidence !== "high"
    ? "(I'm still double-checking some filming details, so verify before you plan around them.)"
    : "";
}

function addMessage(who, text) {
  const div = document.createElement("div");
  div.className = `msg ${who}`;
  div.innerHTML = who === "ai" ? `<span class="avatar">${persona.avatar}</span>${esc(text)}` : esc(text);
  log.appendChild(div);
  div.scrollIntoView({ behavior: "smooth", block: "end" });
}

function fail(msg) {
  header.innerHTML = `<a class="back" href="index.html">← K-Drama Route</a>`;
  addMessage("ai", msg);
}

function shorten(s) {
  if (!s) return "";
  const first = s.split(/(?<=\.)\s/)[0];
  return first || s;
}

function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
