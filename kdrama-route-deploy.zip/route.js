// Creator Route — the people-first click target. "Follow [creator]'s Korea":
// the exact spots they featured, the real clip, and how to get there. Places are
// the destination of the flow (creator → video → place → route), not the entry.

let DATA = { creators: [], visits: [] };

init();

async function init() {
  const id = new URLSearchParams(location.search).get("creator");
  try {
    DATA = await (await fetch("data/visits.json")).json();
  } catch (e) {
    return fail("Could not load data.");
  }
  const c = (DATA.creators || []).find((x) => x.id === id);
  if (!c) return fail("Creator not found.");
  const visits = (DATA.visits || []).filter((v) => v.creatorId === id);
  if (!visits.length) return fail("No spots for this creator yet.");
  render(c, visits);
  if (typeof RR_MEM !== "undefined") RR_MEM.logEvent("creator_route", { place: null, identity_after: identityOfCreator(visits).name });
}

function identityOfCreator(visits) {
  return identityOf(actionVector(visits.map((v) => `${v.spot || ""} ${v.reason || ""}`)))[0];
}

function render(c, visits) {
  const ident = identityOfCreator(visits);
  const totalViews = visits.reduce((a, v) => a + (Number(v.views) || 0), 0);
  // Order spots by reach (most-watched first) — the strongest stops.
  const stops = visits.slice().sort((a, b) => (b.views || 0) - (a.views || 0));

  const stopsHtml = stops
    .map((v, i) => {
      const place = v.place || v.city;
      const thumb = ytThumb(v.videoUrl);
      const thumbHtml = thumb ? `<img class="stop-thumb" src="${thumb}" alt="" loading="lazy" onerror="this.style.display='none'" />` : "";
      return `
        <div class="stop">
          <div class="stop-num">${i + 1}</div>
          <div class="stop-main">
            ${thumbHtml}
            <div class="stop-body">
              <h3>${esc(place)} <span class="region">${esc(v.region || "")}</span></h3>
              <p class="desc">${esc(v.spot || "")}${v.reason ? " · " + esc(v.reason) : ""} · ${fmtViews(v.views)} views</p>
              <div class="stop-actions">
                ${v.videoUrl ? `<a class="map-btn" href="${v.videoUrl}" target="_blank" rel="noopener">▶ Watch</a>` : ""}
                <a class="map-btn ghost-btn" href="place.html?place=${encodeURIComponent(place)}&mode=place">📍 How to get there</a>
              </div>
            </div>
          </div>
        </div>`;
    })
    .join("");

  // "More in this creator's style" — places they DIDN'T go that match their vector.
  const cVec = actionVector(visits.map((v) => `${v.spot || ""} ${v.reason || ""}`));
  const went = new Set(visits.map((v) => v.place || v.city));
  const byPlace = {};
  for (const v of DATA.visits || []) {
    const k = v.place || v.city;
    if (went.has(k)) continue;
    (byPlace[k] = byPlace[k] || []).push(`${v.spot || ""} ${v.reason || ""}`);
  }
  const similar = Object.entries(byPlace)
    .map(([place, texts]) => ({ place, sim: cosine(cVec, actionVector(texts)) }))
    .filter((x) => x.sim > 0.3)
    .sort((a, b) => b.sim - a.sim)
    .slice(0, 4);
  const simHtml = similar.length
    ? similar.map((s) => `<a class="tag" href="place.html?place=${encodeURIComponent(s.place)}&mode=place">${esc(s.place)} <em>${Math.round(s.sim * 100)}%</em></a>`).join(" ")
    : `<span class="conf">—</span>`;

  document.getElementById("route-body").innerHTML = `
    <header class="place-head">
      <p class="identity-pre">Follow their Korea</p>
      <h1>${esc(c.name)}</h1>
      <p class="place-sub">${esc(c.country || "")} · ${fmtSubs(c.subscribers)} · <a href="${c.url}" target="_blank" rel="noopener" style="color:var(--accent-2)">channel ↗</a></p>
      <p class="place-metric"><span class="archetype">${esc(ident.name)}</span> · ${stops.length} spots · ${fmtViews(totalViews)} combined views</p>
    </header>
    <section class="place-sec">
      <h2>The journey</h2>
      ${stopsHtml}
    </section>
    <section class="place-sec">
      <h2>More in ${esc(c.name)}'s style</h2>
      <div class="titles">${simHtml}</div>
    </section>
    <section class="place-sec ratings-soon">
      <h2>Make it your trip <span class="conf">— coming</span></h2>
      <p>This is the page that converts a video into a real trip — so booking lives here, not on a place page: <strong>KTX between these stops · stays · a guided version of ${esc(c.name)}'s journey</strong>. The experience-replication page is the product; the affiliate/booking hooks attach right here.</p>
    </section>`;
  document.title = `${c.name}'s Korea — K-Drama Route`;
}

function fail(msg) {
  document.getElementById("route-body").innerHTML = `<p class="empty">${esc(msg)}</p>`;
}
function fmtSubs(n) { return !n ? "" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M subs" : Math.round(n / 1e3) + "K subs"; }
function fmtViews(n) { return !n ? "—" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : (n / 1e3).toFixed(0) + "K"; }
function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
