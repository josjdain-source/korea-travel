// Global-interest ranking. Ranks Korean cities by how many distinct FOREIGN
// creators visited them, weighted by reach — computed live from data/visits.json.
// Ranks are never hardcoded; add verified visits and the ranking re-derives itself.

const BIG_CITIES = ["Seoul", "Busan", "Jeju"];

let DATA = { creators: [], visits: [] };
let creatorById = {};
let state = { region: "all", hideBig: false, mode: "place", experience: "all", action: null };

const rankingEl = document.getElementById("ranking");
const emptyState = document.getElementById("empty-state");
const resultCount = document.getElementById("result-count");
const regionFilters = document.getElementById("region-filters");
const expFilters = document.getElementById("exp-filters");

init();

async function init() {
  state.action = new URLSearchParams(location.search).get("action"); // V6: browse by action
  try {
    DATA = await (await fetch("data/visits.json")).json();
  } catch (e) {
    DATA = { creators: [], visits: [] };
  }
  creatorById = Object.fromEntries((DATA.creators || []).map((c) => [c.id, c]));
  renderStats();
  buildExperienceFilters();
  buildRegionFilters();
  bindControls();
  render();
}

// Real, computed stats — never aspirational placeholders.
function renderStats() {
  const el = document.getElementById("stats");
  if (!el) return;
  const creators = (DATA.creators || []).length;
  const places = new Set((DATA.visits || []).map((v) => v.place || v.city)).size;
  const videos = (DATA.visits || []).filter((v) => v.videoUrl).length;
  el.innerHTML = `🎥 <strong>${creators}</strong> global creators &nbsp;·&nbsp; 📍 <strong>${places}</strong> places &nbsp;·&nbsp; 👣 <strong>${videos}</strong> real visits <span class="conf">(seed dataset — growing)</span>`;
}

// Aggregate visits → one row per place (or per city, depending on mode).
function aggregate() {
  const keyOf = (v) => (state.mode === "place" ? v.place || v.city : v.city);
  const groups = {};
  for (const v of DATA.visits || []) {
    const key = keyOf(v);
    if (!groups[key]) {
      groups[key] = { label: key, city: v.city, region: v.region, creators: new Set(), reasons: {}, actions: new Set(), totalViews: 0 };
    }
    const g = groups[key];
    g.creators.add(v.creatorId);
    g.totalViews += Number(v.views) || 0;
    if (v.reason) g.reasons[v.reason] = (g.reasons[v.reason] || 0) + 1;
    // V4: actions creators did here (derived from their video text).
    for (const act of actionsOf(`${v.spot || ""} ${v.reason || ""}`)) g.actions.add(act);
  }
  let rows = Object.values(groups).map((g) => ({
    label: g.label,
    city: g.city,
    region: g.region,
    creatorCount: g.creators.size,
    creatorIds: [...g.creators],
    totalViews: g.totalViews,
    reasonCounts: g.reasons,
    actions: [...g.actions],
    topReasons: Object.entries(g.reasons).sort((a, b) => b[1] - a[1]).map(([k]) => k),
    // Global-interest score: distinct-creator count is the primary signal
    // (one mega-creator must not outrank broad interest); reach only breaks ties.
    score: g.creators.size * 1_000_000_000 + g.totalViews,
  }));
  rows.sort((a, b) => b.score - a.score);
  return rows;
}

// Theme/action vocab + scoring (themesOf, actionsOf, themeProfile, dnaPercent,
// cosine) live in engine.js, loaded before this file and shared with place.js.

function buildExperienceFilters() {
  if (!expFilters) return;
  const themes = new Set();
  for (const v of DATA.visits || []) for (const t of themesOf(v.reason)) themes.add(t);
  const list = ["all", ...[...themes].sort()];
  expFilters.innerHTML = list
    .map((t) => `<button class="chip ${t === "all" ? "active" : ""}" data-exp="${esc(t)}">${t === "all" ? "Anything" : esc(t)}</button>`)
    .join("");
  expFilters.querySelectorAll(".chip").forEach((btn) =>
    btn.addEventListener("click", () => {
      state.experience = btn.dataset.exp;
      expFilters.querySelectorAll(".chip").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      render();
    })
  );
}

function buildRegionFilters() {
  const regions = ["all", ...new Set((DATA.visits || []).map((v) => v.region).filter(Boolean))];
  regionFilters.innerHTML = regions
    .map((r) => `<button class="chip ${r === "all" ? "active" : ""}" data-region="${r}">${r === "all" ? "All regions" : esc(r)}</button>`)
    .join("");
  regionFilters.querySelectorAll(".chip").forEach((btn) =>
    btn.addEventListener("click", () => {
      state.region = btn.dataset.region;
      regionFilters.querySelectorAll(".chip").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      render();
    })
  );
}

function bindControls() {
  document.getElementById("hide-big").addEventListener("change", (e) => {
    state.hideBig = e.target.checked;
    render();
  });
  const modeGroup = document.getElementById("mode-toggle");
  if (modeGroup) {
    modeGroup.querySelectorAll(".chip").forEach((btn) =>
      btn.addEventListener("click", () => {
        state.mode = btn.dataset.mode;
        modeGroup.querySelectorAll(".chip").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        render();
      })
    );
  }
}

function render() {
  let rows = aggregate();
  if (state.region !== "all") rows = rows.filter((r) => r.region === state.region);
  if (state.hideBig) rows = rows.filter((r) => !BIG_CITIES.includes(r.city));
  if (state.experience !== "all") rows = rows.filter((r) => themeProfile(r.reasonCounts)[state.experience]);
  if (state.action) rows = rows.filter((r) => r.actions.includes(state.action));

  if (!rows.length) {
    rankingEl.innerHTML = "";
    resultCount.textContent = "";
    emptyState.hidden = false;
    return;
  }
  emptyState.hidden = true;
  resultCount.innerHTML = state.action
    ? `Places where creators: <strong>${esc(state.action)}</strong> — ${rows.length} found &nbsp;<a href="ranking.html" style="color:var(--accent-2)">clear ✕</a>`
    : `${rows.length} place${rows.length === 1 ? "" : "s"} ranked by global creator interest`;

  const maxCreators = Math.max(...rows.map((r) => r.creatorCount));
  rankingEl.innerHTML = rows.map((r, i) => rowHtml(r, i + 1, maxCreators)).join("");
  // Click a row → that place's detail page.
  rankingEl.querySelectorAll(".rank-row").forEach((el) =>
    el.addEventListener("click", () => {
      location.href = `place.html?place=${encodeURIComponent(el.dataset.place)}&mode=${state.mode}`;
    })
  );
}

function rowHtml(r, rank, maxCreators) {
  const stars = "★".repeat(Math.max(1, Math.round((r.creatorCount / maxCreators) * 5))).padEnd(5, "☆");
  const creators = r.creatorIds
    .map((id) => creatorById[id])
    .filter(Boolean)
    .map((c) => `<span class="tag" title="${esc(c.country || "")} · ${fmtSubs(c.subscribers)}">${esc(c.name)}</span>`)
    .join(" ");
  const actions = (r.actions || []).slice(0, 4).map((a) => `<span class="reason">${esc(a)}</span>`).join("");
  // In place mode the row label is the place; show its city. In city mode show the province.
  const sub = state.mode === "place" && r.label !== r.city ? `${esc(r.city)} · ${esc(r.region || "")}` : esc(r.region || "");
  return `
    <li class="rank-row${BIG_CITIES.includes(r.city) ? " big" : ""}" data-place="${esc(r.label)}">
      <div class="rank-num">${rank}</div>
      <div class="rank-body">
        <div class="rank-head">
          <h3>${esc(r.label)}<span class="region">${sub}</span></h3>
          <span class="stars" title="Global interest">${stars}</span>
        </div>
        <p class="rank-stats">${r.creatorCount} foreign creator${r.creatorCount === 1 ? "" : "s"} · ${fmtViews(r.totalViews)} combined views <span class="expand-hint">▸ see who went &amp; how to follow</span></p>
        ${actions ? `<div class="reasons">Creators here: ${actions}</div>` : ""}
        ${creators ? `<div class="titles">${creators}</div>` : ""}
      </div>
    </li>`;
}

function fmtSubs(n) {
  if (!n) return "";
  return n >= 1_000_000 ? (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M subs" : Math.round(n / 1000) + "K subs";
}
function fmtViews(n) {
  if (!n) return "—";
  return n >= 1_000_000 ? (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M" : (n / 1000).toFixed(0) + "K";
}
function esc(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
