// Creator DNA (V11): each creator's travel personality, computed from their
// verified visits — theme profile + dominant traveller archetype + where they went.
// Engine (themeProfile, dnaPercent, archetypeProfile) is shared via engine.js.

let DATA = { creators: [], visits: [] };

init();

async function init() {
  try {
    DATA = await (await fetch("data/visits.json")).json();
  } catch (e) {
    document.getElementById("creators").innerHTML = `<p class="empty">Could not load data.</p>`;
    return;
  }
  render();
}

function render() {
  const cards = (DATA.creators || [])
    .map((c) => {
      const visits = (DATA.visits || []).filter((v) => v.creatorId === c.id);
      if (!visits.length) return null;
      const reasons = {};
      for (const v of visits) if (v.reason) reasons[v.reason] = (reasons[v.reason] || 0) + 1;
      const themeProf = themeProfile(reasons);
      // V15: a creator is an example of a traveler identity (action-space match).
      const actVec = actionVector(visits.map((v) => `${v.spot || ""} ${v.reason || ""}`));
      const identity = identityOf(actVec)[0];
      const places = [...new Set(visits.map((v) => v.place || v.city))];
      const regions = [...new Set(visits.map((v) => v.region).filter(Boolean))].length;
      const themeCount = Object.keys(themeProf).length; // experience diversity
      const totalViews = visits.reduce((a, v) => a + (Number(v.views) || 0), 0);
      // Real YouTube thumbnail from the most-viewed video they made here.
      const top = visits.filter((v) => v.videoUrl).sort((a, b) => (b.views || 0) - (a.views || 0))[0];
      const thumb = top ? ytThumb(top.videoUrl) : null;
      return { c, identity, places, regions, themeCount, totalViews, visitCount: visits.length, thumb };
    })
    .filter(Boolean)
    // most-active creators first
    .sort((a, b) => b.visitCount - a.visitCount);

  // Featured ≠ "most famous". A fuller journey (more places, regions, diversity)
  // makes a stronger entry for trip-generation than raw reach. MVP composite —
  // user-follow-rate joins once that data exists (no fake numbers now).
  const featured = cards.slice().sort((a, b) => featuredScore(b) - featuredScore(a))[0];
  const rest = cards.filter((x) => x.c.id !== (featured && featured.c.id));
  if (featured) document.getElementById("featured").innerHTML = featuredHtml(featured);
  document.getElementById("creators").innerHTML = rest.map(cardHtml).join("");
}

// MVP composite: reach + Korea coverage + region spread + experience diversity.
// Weights are illustrative; tune from data (+ add follow-rate) later.
function featuredScore(x) {
  const reach = Math.log10((x.totalViews || 0) + 10);
  return reach * 1.0 + x.places.length * 1.5 + x.regions * 1.0 + x.themeCount * 1.0;
}

function featuredHtml(x) {
  const { c, identity, places, totalViews, thumb } = x;
  const thumbHtml = thumb
    ? `<img class="featured-thumb" src="${thumb}" alt="" loading="lazy" onerror="this.style.display='none'" />`
    : `<div class="featured-thumb creator-thumb--empty">🎬</div>`;
  return `
    <a class="featured-creator" href="route.html?creator=${encodeURIComponent(c.id)}">
      ${thumbHtml}
      <div class="featured-body">
        <span class="badge">${esc(c.country || "")} · ${fmtSubs(c.subscribers)}</span>
        <h2>${esc(c.name)}</h2>
        <p class="archetype">${esc(identity ? identity.name : "")}</p>
        <p class="desc">${places.length} spots in Korea · ${fmtViews(totalViews)} combined views</p>
        <span class="map-btn">▶ Follow ${esc(c.name)}'s Korea →</span>
      </div>
    </a>`;
}

function cardHtml(x) {
  const { c, identity, places, totalViews, thumb } = x;
  const dominant = identity ? identity.name : "Explorer 🧭";
  const thumbHtml = thumb
    ? `<img class="creator-thumb" src="${thumb}" alt="" loading="lazy" onerror="this.style.display='none'" />`
    : `<div class="creator-thumb creator-thumb--empty">🎬</div>`;
  return `
    <a class="card creator-follow" href="route.html?creator=${encodeURIComponent(c.id)}">
      ${thumbHtml}
      <div class="card-top">
        <span class="badge">${esc(c.country || "")}</span>
        <span class="badge">${fmtSubs(c.subscribers)}</span>
      </div>
      <h3>${esc(c.name)}</h3>
      <p class="archetype">${esc(dominant)}</p>
      <p class="desc">${places.length} place${places.length === 1 ? "" : "s"} in Korea · ${fmtViews(totalViews)} views</p>
      <span class="follow-cta">Follow ${esc(c.name)}'s Korea →</span>
    </a>`;
}

function fmtSubs(n) {
  if (!n) return "";
  return n >= 1_000_000 ? (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M subs" : Math.round(n / 1000) + "K subs";
}
function fmtViews(n) {
  if (!n) return "—";
  return n >= 1_000_000 ? (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M" : (n / 1000).toFixed(0) + "K";
}
function esc(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
